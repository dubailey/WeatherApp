//
//  WeatherCell.swift
//  rainyshinycloudy
//
//  Created by Duncan Bailey on 11/25/16.
//  Copyright © 2016 Duncan Bailey. All rights reserved.
//

import UIKit

class WeatherCell: UITableViewCell {

    @IBOutlet weak var weatherIcon: UIImageView!
    @IBOutlet weak var dayLabel: UILabel!
    @IBOutlet weak var weatherType: UILabel!
    @IBOutlet weak var lowTemp: UILabel!
    @IBOutlet weak var highTemp: UILabel!
    
    func configureCell(foreCast: Forecast) {
        
        lowTemp.text = "\(foreCast.lowTemp)"
        highTemp.text = "\(foreCast.highTemp)"
        weatherType.text = foreCast.weatherType
        dayLabel.text = foreCast.date
        weatherIcon.image = UIImage(named: foreCast.weatherType)
        
        
    }
    
    
    
    
    

}
