//
//  Constants.swift
//  rainyshinycloudy
//
//  Created by Duncan Bailey on 11/24/16.
//  Copyright © 2016 Duncan Bailey. All rights reserved.
//

import Foundation
import CoreLocation

let BASE_URL = "http://api.openweathermap.org/data/2.5/weather?"
let LATITUDE = "lat=\(Location.sharedInstance.latitude!)"
let LONGITUDE = "&lon=\(Location.sharedInstance.longitude!)"
let APP_ID = "&appid="
let API_KEY = "ccd247b13973efa6b5f919ac1062254f"

typealias DownloadComplete = () -> ()

let CURRENT_WEATHER_URL = "http://api.openweathermap.org/data/2.5/weather?lat=\(Location.sharedInstance.latitude!)&lon=\(Location.sharedInstance.longitude!)&appid=ccd247b13973efa6b5f919ac1062254f"
let FORECAST_URL = "http://api.openweathermap.org/data/2.5/forecast/daily?lat=\(Location.sharedInstance.latitude!)&lon=\(Location.sharedInstance.longitude!)&cnt=10&mode=json&appid=ccd247b13973efa6b5f919ac1062254f"


